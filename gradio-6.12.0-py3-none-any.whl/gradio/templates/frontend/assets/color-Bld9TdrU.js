import{o}from"./i18n-Kiq2diRm.js";const t=r=>o[r%o.length];export{t as g};
