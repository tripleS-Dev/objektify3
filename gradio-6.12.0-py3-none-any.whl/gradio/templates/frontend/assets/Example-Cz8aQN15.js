import"./i18n-Kiq2diRm.js";import{a7 as p,t as s,a as x,a0 as f,a8 as m}from"./index-JiPXAygV.js";function l(a,e){m();var t=p();s(()=>f(t,e.value||"")),x(a,t)}export{l as default};
